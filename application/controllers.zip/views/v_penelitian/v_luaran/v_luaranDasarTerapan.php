1. Jurnal Internasional (Wajib)<br>
2. Prosiding Nasional<br>
3. Buku<br>
4. Teknologi Tepat Guna<br>
5. Rekayasa Sosial<br>
6. HKI<br>
7. Lainnya