1. Makalah Ilmiah <br>
2. Jurnal<br>
3. Proposal Penelitian lainnya