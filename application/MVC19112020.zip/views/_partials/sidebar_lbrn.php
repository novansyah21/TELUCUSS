<ul class="sidebar navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('home') ?>">
        <i class="fas fa-fw fa-home"></i>
        <span>Beranda</span>
        </a>
</li>     
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>laboran">
            <i class="fas fa-fw fa-table"></i>
            <span>Data Barang Inventaris</span>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="<?php echo base_url();?>laboran/add">
            <i class="fas fa-fw fa-table"></i>
            <span>Input Data Barang Inventaris</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>laboran/pengajuan">
            <i class="fas fa-fw fa-table"></i>
            <span>Data Pengajuan Barang</span>
          </a>
        </li>
      </ul>