<ul class="sidebar navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('home') ?>">
        <i class="fas fa-fw fa-home"></i>
        <span>Beranda</span>
        </a>
</li>        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>lab">
            <i class="fas fa-fw fa-table"></i>
            <span>Data Barang Inventaris</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>lab/Peminjaman">
            <i class="fas fa-fw fa-table"></i>
            <span>Data Peminjaman</span>
          </a>
        </li>
      </ul>