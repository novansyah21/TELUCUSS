1. Jurnal Internasional (wajib)<br>
2. Prosiding Internasional (wajib)<br>
3. Buku<br>
4. Teknologi Tepat Guna<br>
5. Rekayasa Sosial<br>
6. HKI - Paten (Wajib)<br>
7. Lainnya