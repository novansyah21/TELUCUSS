1. Prosiding Internasional (wajib)<br>
2. Jurnal Internasional<br>
3. Buku<br>
4. Teknologi Tepat Guna<br>
5. Rekayasa Sosial<br>
6. HKI<br>
7. Prototype<br>
8. Lainnya