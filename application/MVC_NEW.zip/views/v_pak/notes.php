<pre>
Catatan :
-  Peraturan berdasarkan buku Pedoman Operasional Penilaian Angka Kredit Kenaikan Jabatan Akademik/Pangkat Dosen (PO 2019)
-  Mengacu pada :
   1. Undang-Undang Nomor 20 tahun 2003 
   2. Undang-Undang Nomor 14 tahun 2005
   3. Peraturan Pemerintah Nomor 37 tahun 2009 
   4. Undang-Undang Nomor 12 tahun 2012 
</pre>