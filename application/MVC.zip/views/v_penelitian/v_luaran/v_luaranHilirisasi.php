<pre id="lembar-pengesahan">
<b>a.  Luaran Wajib</b>
    1. Prototype TRL 6-7
    2. Kekayaan Intelektual (KI)
<b>b. Luaran Tambahan</b>
    3. Publikasi Ilmiah : Pameran Lokal
    4. Proposal Penelitian Eksternal dan/atau Risetdikti:
        a. Program Pengembangan Teknologi Industri (PPTI) Direktorat Jenderal Penguatan Riset dan Pengembangan,
        b. Diseminasi Teknologi ke Masyarakat Direktorat Jenderal Penguatan Riset dan Pengembangan,
        c. Perusahaan Pemula berbasis Teknologi (PPBT) Direktorat Jenderal Penguatan Inovasi,
        d. Program Insensif Teknologi yang dimanfaatkan di Industri Direktorat Jenderal Penguatan Inovasi
</pre>