<script src="<?= base_url('assets/js/fecha.js') ?>"></script>
<script src="<?= base_url('assets/js/hotel-datepicker.js') ?>"></script>